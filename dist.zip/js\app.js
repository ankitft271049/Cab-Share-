// Application State
const State = {
  currentStudent: null,
  activeTab: 'search',
  dashboardView: 'active', // 'active' | 'past'
  lastSearchParams: null,
  pendingRidePost: null,
  tempAuthData: null
};

// GLIM Preset Destinations
const PRESET_DESTINATIONS = [
  'Chennai Airport (MAA) - Domestic',
  'Chennai Airport (MAA) - International',
  'Chennai Central Railway Station (MAS)',
  'Chennai Egmore Railway Station (MS)',
  'Tambaram Railway Station / Bus Stand',
  'CMBT / Kilambakkam (KCBT) Bus Terminus',
  'GLIM Campus (Manamai) - Return to Campus',
  'Other / Custom Chennai Location'
];

// Initialize on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initUserSession();
  initEventListeners();
  checkSyncStatus();
  loadCampusStats();
  setDefaultDates();
  
  // Set default view
  switchTab('search');
});

// 1. Session & Auth Management
async function initUserSession() {
  const saved = localStorage.getItem('glim_cab_user');
  if (saved) {
    try {
      State.currentStudent = JSON.parse(saved);
      updateUserUI();

      // Background re-sync with server to ensure profile exists in DB
      if (State.currentStudent.roll_number && State.currentStudent.phone_number) {
        API.login({
          roll_number: State.currentStudent.roll_number,
          full_name: State.currentStudent.full_name || 'GLIM Student',
          phone_number: State.currentStudent.phone_number,
          whatsapp_number: State.currentStudent.whatsapp_number || State.currentStudent.phone_number,
          cohort: State.currentStudent.cohort
        }).then(res => {
          if (res.student) {
            State.currentStudent = res.student;
            localStorage.setItem('glim_cab_user', JSON.stringify(res.student));
            updateUserUI();
          }
        }).catch(err => {
          console.warn('Session sync note:', err);
        });
      }
    } catch (e) {
      localStorage.removeItem('glim_cab_user');
    }
  }

  // Prompt student to log in if no active session
  if (!State.currentStudent || !State.currentStudent.roll_number) {
    setTimeout(() => {
      openLoginModal();
    }, 200);
  }
}

function updateUserUI() {
  const container = document.getElementById('userProfileContainer');
  const sheetsBtn = document.getElementById('sheetsSyncBtn');

  if (!State.currentStudent) {
    if (sheetsBtn) sheetsBtn.style.display = 'none';
    container.innerHTML = `
      <button class="btn btn-accent btn-sm" onclick="openLoginModal()">
        <span>👤</span> Student Login
      </button>
    `;
    return;
  }

  const isAdmin = (State.currentStudent.is_admin || State.currentStudent.roll_number === 'FT271049');
  
  // Show Cloud Sync button ONLY for Admin FT271049
  if (sheetsBtn) {
    sheetsBtn.style.display = isAdmin ? 'inline-flex' : 'none';
  }

  const initials = (State.currentStudent.full_name || 'GL')
    .split(' ')
    .map(n => n[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  container.innerHTML = `
    <div class="user-profile-header">
      <div class="user-avatar" style="${isAdmin ? 'background: var(--glim-gold); color: #000;' : ''}">${initials}</div>
      <div class="user-info-text">
        <span class="user-info-name">
          ${escapeHTML(State.currentStudent.full_name)}
          ${isAdmin ? '<span style="background: var(--glim-gold); color: #000; font-size: 0.65rem; font-weight: 800; padding: 0.1rem 0.4rem; border-radius: 4px; margin-left: 0.3rem;">👑 ADMIN</span>' : ''}
        </span>
        <span class="user-info-roll">${escapeHTML(State.currentStudent.roll_number)} • ${escapeHTML(State.currentStudent.cohort || 'GLIM')}</span>
      </div>
      <button class="btn-switch-user" onclick="openLoginModal()" title="Switch Account">Switch</button>
    </div>
  `;
}

function openLoginModal() {
  const modal = document.getElementById('loginModal');
  if (!modal) return;

  if (State.currentStudent) {
    const rollEl = document.getElementById('loginRoll');
    const nameEl = document.getElementById('loginName');
    const phoneEl = document.getElementById('loginPhone');
    if (rollEl) rollEl.value = State.currentStudent.roll_number || '';
    if (nameEl) nameEl.value = State.currentStudent.full_name || '';
    if (phoneEl) phoneEl.value = State.currentStudent.phone_number || '';
  }
  
  modal.classList.add('active');
  modal.style.display = 'flex';
  modal.style.opacity = '1';
  modal.style.visibility = 'visible';
  modal.style.pointerEvents = 'auto';

  const rollInput = document.getElementById('loginRoll');
  if (rollInput) {
    setTimeout(() => rollInput.focus(), 50);
  }
}

function closeLoginModal() {
  const modal = document.getElementById('loginModal');
  if (!modal) return;
  modal.classList.remove('active');
  modal.style.display = 'none';
  modal.style.opacity = '0';
  modal.style.visibility = 'hidden';
  modal.style.pointerEvents = 'none';
}

// Direct Student Login (No OTP required)
async function handleDirectLogin(e) {
  e.preventDefault();
  const roll = document.getElementById('loginRoll').value.trim().toUpperCase();
  const name = document.getElementById('loginName').value.trim();
  const phone = document.getElementById('loginPhone').value.trim().replace(/\D/g, '');

  if (!roll || !name || !phone || phone.length < 10) {
    showToast('Please enter a valid Roll Number, Full Name, and 10-digit WhatsApp Number', 'warning');
    return;
  }

  const btn = document.getElementById('btnLoginSubmit');
  btn.disabled = true;
  btn.innerHTML = '<span>⏳</span> Logging in...';

  try {
    const res = await API.login({
      roll_number: roll,
      full_name: name,
      phone_number: phone,
      whatsapp_number: phone,
      cohort: roll.startsWith('FT') ? 'FT Batch' : (roll.startsWith('DM') ? 'DM Batch' : 'GLIM')
    });

    State.currentStudent = res.student;
    localStorage.setItem('glim_cab_user', JSON.stringify(res.student));
    updateUserUI();
    closeLoginModal();
    showToast(`Welcome, ${res.student.full_name}! 👋 Logged in successfully.`, 'success');

    if (State.pendingRidePost) {
      const pending = State.pendingRidePost;
      State.pendingRidePost = null;
      submitRidePostData(pending);
      return;
    }

    if (State.activeTab === 'dashboard') {
      loadMyRides();
    }
    loadCampusStats();
  } catch (err) {
    showToast(err.message || 'Login failed. Please try again.', 'danger');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '🚀 Login & Continue';
  }
}



// 2. Tab Navigation
function switchTab(tabId) {
  State.activeTab = tabId;
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });

  document.querySelectorAll('.tab-panel').forEach(panel => {
    panel.style.display = panel.id === `panel-${tabId}` ? 'block' : 'none';
  });

  if (tabId === 'pool') {
    loadPublicPool();
  } else if (tabId === 'dashboard') {
    if (!State.currentStudent) {
      openLoginModal();
      showToast('Please log in to view your dashboard and manage rides', 'info');
    }
    loadMyRides();
  } else if (tabId === 'post') {
    if (!State.currentStudent) {
      openLoginModal();
      showToast('Please log in with your GLIM Roll Number to post a ride', 'info');
    }
  }
}

// 3. Date & Time Defaults
function setDefaultDates() {
  const today = new Date();
  const dateStr = today.toISOString().split('T')[0];
  
  const searchDate = document.getElementById('searchDate');
  const postDate = document.getElementById('postDate');

  if (searchDate) {
    searchDate.min = dateStr;
    searchDate.value = dateStr;
  }
  if (postDate) {
    postDate.min = dateStr;
    postDate.value = dateStr;
  }

  const nextHour = (today.getHours() + 1) % 24;
  const formattedHour = String(nextHour).padStart(2, '0') + ':00';
  
  const searchTime = document.getElementById('searchTime');
  const postTime = document.getElementById('postTime');
  if (searchTime && !searchTime.value) searchTime.value = formattedHour;
  if (postTime && !postTime.value) postTime.value = formattedHour;
}

// 4. Search & Matching Logic (±1 Hour Window, Auto-filters past rides & matches Origin + Destination)
async function handleSearchRides(e) {
  if (e) e.preventDefault();

  const origin = document.getElementById('searchOrigin') ? document.getElementById('searchOrigin').value : 'GLIM Campus (Manamai)';
  const destination = document.getElementById('searchDestination').value;
  const date = document.getElementById('searchDate').value;
  const time = document.getElementById('searchTime').value;

  if (!destination || !date || !time) {
    showToast('Please select destination, date and time', 'warning');
    return;
  }

  State.lastSearchParams = { origin, destination, date, time };

  const resultsContainer = document.getElementById('searchResultsSection');
  resultsContainer.innerHTML = `
    <div class="card" style="text-align:center; padding: 2.5rem;">
      <div style="font-size: 1.5rem; margin-bottom: 0.5rem;">🔍 Searching for GLIM buddies...</div>
      <p style="color: var(--text-muted);">Finding students traveling from <strong>${escapeHTML(origin)}</strong> to <strong>${escapeHTML(destination)}</strong> on <strong>${date}</strong> around <strong>${time}</strong> (±1 hr window)</p>
    </div>
  `;

  try {
    const res = await API.searchRides({
      origin,
      destination,
      travel_date: date,
      travel_time: time,
      current_student_id: State.currentStudent ? State.currentStudent.id : ''
    });

    renderSearchResults(res, { origin, destination, date, time });
  } catch (err) {
    resultsContainer.innerHTML = `
      <div class="card" style="text-align: center; color: var(--danger); padding: 2rem;">
        <h3>Error Searching Rides</h3>
        <p>${escapeHTML(err.message)}</p>
      </div>
    `;
  }
}

function renderSearchResults(data, searchCriteria) {
  const container = document.getElementById('searchResultsSection');
  const exactMatches = data.exact_matches || [];
  const sameDayMatches = data.same_day_matches || [];

  let html = `
    <div class="card" style="background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);">
      <div class="card-header">
        <div class="card-title">
          <span>🎯</span> Results: ${escapeHTML(searchCriteria.origin)} ➔ ${escapeHTML(searchCriteria.destination)}
        </div>
        <span class="meta-tag" style="background: var(--primary); color: #FFF; font-weight: 600;">
          📅 ${searchCriteria.date} @ ${searchCriteria.time} (±1 hr window)
        </span>
      </div>
  `;

  // 1. EXACT ±1 HOUR MATCHES
  if (exactMatches.length > 0) {
    html += `
      <div class="match-section-title">
        <span>✨ Best Route & Timing Matches (Within ±1 Hour)</span>
        <span class="badge" style="background: var(--accent); color: #000; font-weight: 700; padding: 0.2rem 0.6rem; border-radius: 99px; font-size: 0.8rem;">
          ${exactMatches.length} ${exactMatches.length === 1 ? 'Student Match' : 'Students Match'}
        </span>
      </div>
      <div class="matches-grid">
        ${exactMatches.map(ride => renderRideCard(ride, true)).join('')}
      </div>
    `;
  } else {
    html += `
      <div class="empty-state" style="padding: 2rem 1rem;">
        <div class="empty-state-icon">⏰</div>
        <h3>No exact ±1 hour match found for this route</h3>
        <p>No student has posted from ${escapeHTML(searchCriteria.origin)} to ${escapeHTML(searchCriteria.destination)} within 1 hour of ${searchCriteria.time} on ${searchCriteria.date} yet.</p>
      </div>
    `;
  }

  // 2. SAME-DAY OTHER TIMING MATCHES
  if (sameDayMatches.length > 0) {
    html += `
      <div class="match-section-title" style="margin-top: 2rem; border-top: 1px dashed var(--border-color); padding-top: 1.5rem;">
        <span>🕒 Other Students on Same Route (${searchCriteria.date})</span>
        <span style="font-size: 0.85rem; color: var(--text-muted);">${sameDayMatches.length} available</span>
      </div>
      <div class="matches-grid">
        ${sameDayMatches.map(ride => renderRideCard(ride, false)).join('')}
      </div>
    `;
  }

  // 3. PUBLIC POOL POST CALL-TO-ACTION
  html += `
      <div class="post-fallback-box">
        <h3>🚀 None of these match your timing?</h3>
        <p>Post your travel plan to the <strong>GLIM Public Pool</strong>. Other students will see your post and connect with you on WhatsApp!</p>
        <button class="btn btn-accent btn-lg" onclick="prefillAndSwitchToPost('${escapeHTML(searchCriteria.origin)}', '${escapeHTML(searchCriteria.destination)}', '${searchCriteria.date}', '${searchCriteria.time}')">
          <span>➕</span> Post My Ride to Public Pool Now
        </button>
      </div>
    </div>
  `;

  container.innerHTML = html;
  container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function prefillAndSwitchToPost(origin, destination, date, time) {
  if (document.getElementById('postOrigin')) document.getElementById('postOrigin').value = origin;
  document.getElementById('postDestination').value = destination;
  document.getElementById('postDate').value = date;
  document.getElementById('postTime').value = time;
  switchTab('post');
  showToast('Trip details pre-filled for your post!', 'info');
}

// 5. Ride Card Component (With Remaining Seats Indicator)
function renderRideCard(ride, isExactMatch) {
  const isMine = State.currentStudent && State.currentStudent.id === ride.student_id;
  const isCurrentUserAdmin = (State.currentStudent && (State.currentStudent.is_admin || State.currentStudent.roll_number === 'FT271049'));

  const studentName = String(ride.student_name || 'GLIM Student');
  const studentInitials = studentName
    .split(' ')
    .filter(Boolean)
    .map(n => n[0] || '')
    .join('')
    .substring(0, 2)
    .toUpperCase() || 'GL';

  const totalSeats = Number(ride.total_seats || ride.seats_count) || 1;
  const filledSeats = Number(ride.filled_seats) || 0;
  const remainingSeats = Math.max(0, totalSeats - filledSeats);
  const isFull = remainingSeats === 0;

  // WhatsApp Deep Link Generator with bulletproof string casting
  const rawNumber = String(ride.whatsapp_number || ride.phone_number || '').replace(/\D/g, '');
  const waNumber = rawNumber.startsWith('91') && rawNumber.length > 10 ? rawNumber.slice(2) : rawNumber;
  const waMessage = encodeURIComponent(
    `Hi ${studentName}! 👋\nI saw your cab share post on GLIM Cab Share for *${ride.destination}* on *${ride.travel_date}* around *${ride.travel_time}*.\nAre there still seats available to share?`
  );
  const waUrl = `https://wa.me/91${waNumber}?text=${waMessage}`;

  const isHaveCab = ride.ride_type === 'HAVE_CAB_OFFERING_SEATS';
  const statusStr = String(ride.status || 'ACTIVE');

  return `
    <div class="ride-card ${isExactMatch ? 'exact-match' : ''}">
      <div>
        <div class="ride-badge-top">
          <span class="ride-type-pill ${isHaveCab ? 'have-cab' : 'need-cab'}">
            ${isHaveCab ? '🚖 Cab Booked (Offering Seats)' : '🙋 Seeking Cab / Co-passengers'}
          </span>
          
          ${ride.diff_label ? `
            <span class="time-diff-badge ${ride.diff_minutes === 0 ? 'exact' : ''}">
              ⏱️ ${escapeHTML(ride.diff_label)}
            </span>
          ` : `
            <span class="status-badge ${statusStr.toLowerCase()}">${escapeHTML(statusStr)}</span>
          `}
        </div>

        <div class="student-profile-row" style="margin: 0.9rem 0;">
          <div class="student-avatar">${studentInitials}</div>
          <div class="student-details">
            <h4>${escapeHTML(studentName)} ${isMine ? '<span style="font-size:0.75rem; color:var(--accent);">(You)</span>' : ''}</h4>
            <span>🎓 ${escapeHTML(ride.roll_number || '')} • ${escapeHTML(ride.cohort || 'GLIM')}</span>
          </div>
        </div>

        <div class="route-info">
          <div class="route-point">
            <span class="dot origin"></span>
            <span><strong>From:</strong> ${escapeHTML(ride.origin || 'GLIM Campus')}</span>
          </div>
          <div class="route-point">
            <span class="dot dest"></span>
            <span><strong>To:</strong> ${escapeHTML(ride.destination)}</span>
          </div>

          <div class="route-meta-tags">
            <span class="meta-tag">📅 ${ride.travel_date}</span>
            <span class="meta-tag">⏰ ${ride.travel_time}</span>
            
            ${isHaveCab ? `
              <span class="meta-tag" style="background: ${isFull ? 'var(--danger-bg)' : 'var(--success-bg)'}; color: ${isFull ? 'var(--danger)' : 'var(--success)'}; font-weight: 700;">
                ${isFull ? '🔴 Cab Full (0 Seats Left)' : `🟢 ${remainingSeats} of ${totalSeats} Seats Left`}
              </span>
            ` : `
              <span class="meta-tag">👥 Seeking ${totalSeats} Seat(s)</span>
            `}

            <span class="meta-tag">🧳 ${escapeHTML(ride.luggage_size || 'Medium')} Bags</span>
            ${ride.flight_train_no ? `<span class="meta-tag flight-tag">✈️/🚆 ${escapeHTML(ride.flight_train_no)}</span>` : ''}
          </div>
        </div>

        ${ride.notes ? `
          <div class="ride-notes" style="margin-top: 0.75rem;">
            "${escapeHTML(ride.notes)}"
          </div>
        ` : ''}
      </div>

      <div class="card-actions" style="flex-wrap: wrap;">
        ${!isMine ? `
          <a href="${waUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp" style="flex: 1; min-width: 160px;">
            <span>💬</span> Connect on WhatsApp
          </a>
          <button class="btn btn-outline btn-sm" onclick="copyContact('${escapeHTML(ride.phone_number)}', '${escapeHTML(ride.student_name)}')" title="Copy Phone Number">
            📞
          </button>
          ${isCurrentUserAdmin ? `
            <button class="btn btn-danger-outline btn-sm" onclick="adminDeleteRide('${ride.id}', '${escapeHTML(ride.student_name)}')" title="Admin: Delete this post">
              🛡️ Admin Delete
            </button>
          ` : ''}
        ` : `
          <button class="btn btn-accent btn-sm" style="flex: 1;" onclick="switchTab('dashboard')">
            Manage in My Dashboard
          </button>
        `}
      </div>
    </div>
  `;
}

// Admin delete post handler
async function adminDeleteRide(rideId, studentName) {
  if (!confirm(`[Campus Admin FT271049]\n\nAre you sure you want to remove the ride post created by ${studentName}?`)) {
    return;
  }

  try {
    const res = await API.deleteRide(rideId, State.currentStudent.id);
    showToast(res.message || 'Ride post deleted by Admin (FT271049)', 'info');

    if (State.activeTab === 'pool') loadPublicPool();
    if (State.activeTab === 'dashboard') loadMyRides();
    if (State.lastSearchParams) handleSearchRides();
    loadCampusStats();
  } catch (err) {
    showToast(err.message || 'Admin delete failed', 'danger');
  }
}

// 6. Post Ride to Public Pool
async function handleCreateRide(e) {
  if (e) e.preventDefault();

  const origin = document.getElementById('postOrigin').value;
  const destination = document.getElementById('postDestination').value;
  const travel_date = document.getElementById('postDate').value;
  const travel_time = document.getElementById('postTime').value;
  const ride_type = document.getElementById('postRideType').value;
  const total_seats = parseInt(document.getElementById('postSeats').value, 10) || 1;
  const luggage_size = document.getElementById('postLuggage').value;
  const flight_train_no = document.getElementById('postFlightTrain').value;
  const notes = document.getElementById('postNotes').value;

  if (!destination || !travel_date || !travel_time) {
    showToast('Please select destination, date and preferred time', 'warning');
    return;
  }

  const ridePayload = {
    origin,
    destination,
    travel_date,
    travel_time,
    ride_type,
    seats_count: total_seats,
    total_seats: total_seats,
    luggage_size,
    flight_train_no,
    notes
  };

  if (!State.currentStudent) {
    State.pendingRidePost = ridePayload;
    openLoginModal();
    showToast('Please enter your FT/DM number to publish', 'info');
    return;
  }

  await submitRidePostData(ridePayload);
}

async function submitRidePostData(ridePayload) {
  try {
    const res = await API.createRide({
      ...ridePayload,
      student_id: State.currentStudent ? State.currentStudent.id : null,
      student_profile: State.currentStudent
    });

    if (res.student && (!State.currentStudent || !State.currentStudent.id)) {
      State.currentStudent = res.student;
      localStorage.setItem('glim_cab_user', JSON.stringify(res.student));
      updateUserUI();
    }

    showToast('🎉 Ride posted to GLIM Public Pool successfully!', 'success');
    
    const form = document.getElementById('postRideForm');
    if (form) form.reset();
    setDefaultDates();
    loadCampusStats();

    switchTab('dashboard');
  } catch (err) {
    console.error('Post error:', err);
    showToast(err.message || 'Failed to post ride. Please try again.', 'danger');
  }
}

// 7. Public Pool Feed (Explore all posts with filters)
async function loadPublicPool() {
  const container = document.getElementById('poolFeedContainer');
  container.innerHTML = `<div style="text-align: center; padding: 2rem;">Loading public campus posts...</div>`;

  const destFilter = document.getElementById('poolDestFilter').value;
  const dateFilter = document.getElementById('poolDateFilter').value;
  const typeFilter = document.getElementById('poolTypeFilter').value;

  try {
    const res = await API.getPublicPool({
      destination: destFilter,
      date: dateFilter,
      ride_type: typeFilter
    });

    if (!res.posts || res.posts.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📭</div>
          <h3>No Upcoming Public Pool Posts Found</h3>
          <p>Past rides are automatically filtered out. Be the first to post a new ride request!</p>
          <button class="btn btn-primary" onclick="switchTab('post')" style="margin-top: 1rem;">
            <span>➕</span> Post a Ride Request
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="matches-grid">
        ${res.posts.map(p => renderRideCard(p, false)).join('')}
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div style="color: var(--danger); text-align: center;">Failed to load pool: ${escapeHTML(err.message)}</div>`;
  }
}

// 8. Student Dashboard (My Rides with Active vs Past Separation & Seat Tracker)
function setDashboardView(view) {
  State.dashboardView = view;
  document.getElementById('dashboardTabActive').className = view === 'active' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-outline';
  document.getElementById('dashboardTabPast').className = view === 'past' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-outline';
  loadMyRides();
}

async function loadMyRides() {
  const container = document.getElementById('myRidesContainer');
  
  if (!State.currentStudent) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔒</div>
        <h3>Login Required</h3>
        <p>Please log in with your FT/DM number to view and manage your posted rides.</p>
        <button class="btn btn-primary" onclick="openLoginModal()" style="margin-top: 1rem;">Student Login</button>
      </div>
    `;
    return;
  }

  container.innerHTML = `<div style="text-align: center; padding: 2rem;">Loading your rides...</div>`;

  try {
    const res = await API.getMyRides(State.currentStudent.id);
    State.myActiveRides = res.active_rides || [];
    State.myPastRides = res.past_rides || [];
    const ridesToShow = State.dashboardView === 'active' ? State.myActiveRides : State.myPastRides;

    if (ridesToShow.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">${State.dashboardView === 'active' ? '🚕' : '📜'}</div>
          <h3>${State.dashboardView === 'active' ? 'No Active & Upcoming Rides' : 'No Past Rides'}</h3>
          <p>${State.dashboardView === 'active' ? 'You currently have no upcoming active travel posts.' : 'Completed and past expired rides will appear here.'}</p>
          ${State.dashboardView === 'active' ? `
            <button class="btn btn-accent" onclick="switchTab('post')" style="margin-top: 1rem;">
              <span>➕</span> Post a New Ride
            </button>
          ` : ''}
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 1rem;">
        ${ridesToShow.map(r => renderDashboardRideItem(r)).join('')}
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div style="color: var(--danger); text-align: center;">Error loading rides: ${escapeHTML(err.message)}</div>`;
  }
}

function renderDashboardRideItem(ride) {
  const isFound = ride.status === 'FOUND';
  const isCancelled = ride.status === 'CANCELLED';
  const isExpired = ride.status === 'EXPIRED';
  const isActive = ride.status === 'ACTIVE' && !ride.is_past;

  const total = Number(ride.total_seats || ride.seats_count) || 1;
  const filled = Number(ride.filled_seats) || 0;
  const remaining = Math.max(0, total - filled);
  const isHaveCab = ride.ride_type === 'HAVE_CAB_OFFERING_SEATS';
  const statusStr = String(ride.status || 'ACTIVE');

  return `
    <div class="card" style="margin-bottom: 0; border-left: 4px solid ${isActive ? 'var(--success)' : (isFound ? 'var(--info)' : 'var(--danger)')};">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
        <div style="flex: 1; min-width: 280px;">
          <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.5rem;">
            <span class="status-badge ${statusStr.toLowerCase()}">${isFound ? '✅ Buddy Found' : (isExpired ? '⌛ Expired' : escapeHTML(statusStr))}</span>
            <span class="meta-tag">📅 ${escapeHTML(String(ride.travel_date || ''))} @ ${escapeHTML(String(ride.travel_time || ''))}</span>
            <span class="meta-tag">${isHaveCab ? '🚖 Cab Booked (Offering Seats)' : '🙋 Looking for Cab'}</span>
          </div>

          <h3 style="font-size: 1.15rem; color: var(--primary); margin-bottom: 0.25rem;">
            ${escapeHTML(ride.origin || 'GLIM Campus')} ➔ ${escapeHTML(ride.destination)}
          </h3>

          <!-- Seat Progress Bar & Co-passenger Adjuster -->
          ${isHaveCab ? `
            <div style="background: #F8FAFC; padding: 0.6rem 0.8rem; border-radius: var(--radius-sm); margin: 0.6rem 0; border: 1px solid var(--border-color); max-width: 420px;">
              <div style="display: flex; justify-content: space-between; font-size: 0.82rem; font-weight: 600; margin-bottom: 0.3rem;">
                <span>👥 Seat Occupancy:</span>
                <span style="color: ${remaining === 0 ? 'var(--danger)' : 'var(--success)'};">${filled} of ${total} Filled (${remaining} Left)</span>
              </div>
              
              <div style="display: flex; gap: 0.5rem; align-items: center; margin-top: 0.4rem;">
                <button class="btn btn-outline btn-sm" onclick="handleAdjustSeats('${ride.id}', -1)" ${filled <= 0 ? 'disabled' : ''} title="Remove 1 Co-passenger (Freed up seat)">
                  ➖ Free a Seat
                </button>
                <button class="btn btn-accent btn-sm" onclick="handleAdjustSeats('${ride.id}', 1)" ${filled >= total ? 'disabled' : ''} title="Add 1 Co-passenger who joined">
                  ➕ Add Buddy Joined
                </button>
              </div>
            </div>
          ` : ''}

          <div class="route-meta-tags" style="margin-top: 0.5rem;">
            <span class="meta-tag">🧳 ${escapeHTML(ride.luggage_size || 'Medium')} Bags</span>
            ${ride.flight_train_no ? `<span class="meta-tag flight-tag">✈️/🚆 ${escapeHTML(ride.flight_train_no)}</span>` : ''}
          </div>

          ${ride.notes ? `<p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.5rem;">"${escapeHTML(ride.notes)}"</p>` : ''}
        </div>

        <div style="display: flex; flex-direction: column; gap: 0.5rem; align-items: flex-end; min-width: 170px;">
          <button class="btn btn-outline btn-sm" onclick="openEditRideModal('${ride.id}')" style="width: 100%;">
            ✏️ Edit Details
          </button>
          ${isActive ? `
            <button class="btn btn-accent btn-sm" onclick="updateStatus('${ride.id}', 'FOUND')" style="width: 100%;">
              ✅ Mark Buddy Found
            </button>
            <button class="btn btn-outline btn-sm" onclick="updateStatus('${ride.id}', 'CANCELLED')" style="width: 100%;">
              ❌ Cancel Post
            </button>
          ` : `
            <button class="btn btn-outline btn-sm" onclick="updateStatus('${ride.id}', 'ACTIVE')" style="width: 100%;">
              🔄 Reactivate Post
            </button>
          `}
          <button class="btn btn-danger-outline btn-sm" onclick="deleteRidePost('${ride.id}')" style="margin-top: 0.25rem; width: 100%;">
            🗑️ Delete
          </button>
        </div>
      </div>
    </div>
  `;
}

// Adjust seats increment/decrement
async function handleAdjustSeats(rideId, delta) {
  try {
    const res = await API.updateSeats(rideId, {
      delta,
      student_id: State.currentStudent ? State.currentStudent.id : null
    });
    showToast(res.message || 'Seat count updated!', 'success');
    loadMyRides();
    loadCampusStats();
  } catch (err) {
    showToast(err.message || 'Failed to update seats', 'danger');
  }
}

// Edit Ride Handlers
async function openEditRideModal(rideId) {
  try {
    const modal = document.getElementById('editRideModal');
    if (!modal) return;

    // Check in-memory store first for instantaneous response
    let r = null;
    if (State.myActiveRides && State.myActiveRides.length) {
      r = State.myActiveRides.find(item => String(item.id) === String(rideId));
    }
    if (!r && State.myPastRides && State.myPastRides.length) {
      r = State.myPastRides.find(item => String(item.id) === String(rideId));
    }
    if (!r && State.exactMatches && State.exactMatches.length) {
      r = State.exactMatches.find(item => String(item.id) === String(rideId));
    }

    if (!r) {
      const res = await API.getRide(rideId);
      r = (res && res.ride) ? res.ride : res;
    }

    if (!r || !r.id) {
      showToast('Could not load ride details', 'danger');
      return;
    }

    const idEl = document.getElementById('editRideId');
    const originEl = document.getElementById('editOrigin');
    const destEl = document.getElementById('editDestination');
    const dateEl = document.getElementById('editDate');
    const timeEl = document.getElementById('editTime');
    const typeEl = document.getElementById('editRideType');
    const totalEl = document.getElementById('editTotalSeats');
    const filledEl = document.getElementById('editFilledSeats');
    const lugEl = document.getElementById('editLuggage');
    const flightEl = document.getElementById('editFlightTrain');
    const notesEl = document.getElementById('editNotes');

    if (idEl) idEl.value = r.id;

    // Set Origin with fallback
    if (originEl) {
      const targetOrigin = r.origin || 'GLIM Campus (Manamai)';
      let matched = false;
      for (let opt of originEl.options) {
        if (opt.value === targetOrigin) {
          originEl.value = targetOrigin;
          matched = true;
          break;
        }
      }
      if (!matched && targetOrigin) {
        const customOpt = new Option(targetOrigin, targetOrigin, true, true);
        originEl.add(customOpt);
      }
    }

    // Set Destination with fallback
    if (destEl) {
      const targetDest = r.destination || '';
      let matched = false;
      for (let opt of destEl.options) {
        if (opt.value === targetDest) {
          destEl.value = targetDest;
          matched = true;
          break;
        }
      }
      if (!matched && targetDest) {
        const customOpt = new Option(targetDest, targetDest, true, true);
        destEl.add(customOpt);
      }
    }

    // Strictly normalize date to YYYY-MM-DD for HTML5 date input
    let normDate = '';
    if (r.travel_date) {
      const dStr = String(r.travel_date).trim();
      if (dStr.includes('T')) {
        normDate = dStr.split('T')[0];
      } else if (dStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
        normDate = dStr;
      } else {
        try {
          const dObj = new Date(dStr);
          if (!isNaN(dObj.getTime())) {
            const y = dObj.getFullYear();
            const m = String(dObj.getMonth() + 1).padStart(2, '0');
            const d = String(dObj.getDate()).padStart(2, '0');
            normDate = `${y}-${m}-${d}`;
          }
        } catch (e) {}
      }
    }
    if (dateEl) dateEl.value = normDate;

    // Strictly normalize time to HH:MM for HTML5 time input
    let normTime = '';
    if (r.travel_time) {
      const tStr = String(r.travel_time).trim();
      const match = tStr.match(/(\d{1,2}):(\d{2})/);
      if (match) {
        normTime = `${match[1].padStart(2, '0')}:${match[2]}`;
      } else {
        normTime = tStr;
      }
    }
    if (timeEl) timeEl.value = normTime;

    if (typeEl) typeEl.value = r.ride_type || 'LOOKING_FOR_CAB';
    if (totalEl) totalEl.value = String(r.total_seats || r.seats_count || 3);
    if (filledEl) filledEl.value = String(r.filled_seats || 0);
    if (lugEl) lugEl.value = r.luggage_size || 'Medium';
    if (flightEl) flightEl.value = r.flight_train_no || '';
    if (notesEl) notesEl.value = r.notes || '';

    modal.classList.add('active');
    modal.style.display = 'flex';
    modal.style.opacity = '1';
    modal.style.visibility = 'visible';
    modal.style.pointerEvents = 'auto';
  } catch (err) {
    showToast(err.message || 'Error opening edit modal', 'danger');
  }
}

function closeEditRideModal() {
  const modal = document.getElementById('editRideModal');
  if (!modal) return;
  modal.classList.remove('active');
  modal.style.display = 'none';
  modal.style.opacity = '0';
  modal.style.visibility = 'hidden';
  modal.style.pointerEvents = 'none';
}

async function handleEditRideSubmit(e) {
  e.preventDefault();

  const rideId = document.getElementById('editRideId').value;
  if (!rideId) return;

  const origin = document.getElementById('editOrigin').value;
  const destination = document.getElementById('editDestination').value;
  const travel_date = document.getElementById('editDate').value;
  const travel_time = document.getElementById('editTime').value;
  const ride_type = document.getElementById('editRideType').value;
  const total_seats = parseInt(document.getElementById('editTotalSeats').value, 10) || 1;
  const filled_seats = parseInt(document.getElementById('editFilledSeats').value, 10) || 0;
  const luggage_size = document.getElementById('editLuggage').value;
  const flight_train_no = document.getElementById('editFlightTrain').value;
  const notes = document.getElementById('editNotes').value;

  if (!destination || !travel_date || !travel_time) {
    showToast('Destination, date and departure time are required', 'warning');
    return;
  }

  const saveBtn = e.target.querySelector('button[type="submit"]');
  const originalBtnText = saveBtn ? saveBtn.innerHTML : 'Save Changes';
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.innerHTML = '⏳ Saving...';
  }

  try {
    const res = await API.updateRide(rideId, {
      student_id: State.currentStudent ? State.currentStudent.id : null,
      origin,
      destination,
      travel_date,
      travel_time,
      ride_type,
      total_seats,
      filled_seats,
      luggage_size,
      flight_train_no,
      notes
    });

    showToast('✨ Ride details updated successfully!', 'success');
    closeEditRideModal();
    loadMyRides();
    loadCampusStats();

    if (State.lastSearchParams) {
      handleSearchRides();
    }
  } catch (err) {
    showToast(err.message || 'Failed to update ride', 'danger');
  } finally {
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.innerHTML = originalBtnText;
    }
  }
}

async function updateStatus(rideId, status) {
  try {
    const res = await API.updateRideStatus(rideId, status, State.currentStudent.id);
    showToast(res.message || 'Status updated!', 'success');
    loadMyRides();
    loadCampusStats();
  } catch (err) {
    showToast(err.message || 'Failed to update status', 'danger');
  }
}

async function deleteRidePost(rideId) {
  if (!confirm('Are you sure you want to permanently delete this ride post?')) return;
  try {
    await API.deleteRide(rideId, State.currentStudent.id);
    showToast('Ride post deleted', 'info');
    loadMyRides();
    loadCampusStats();
  } catch (err) {
    showToast(err.message || 'Failed to delete', 'danger');
  }
}

// 9. Live Campus Stats
async function loadCampusStats() {
  // 1. Instant optimistic cached stats
  const cached = localStorage.getItem('glim_cached_stats');
  if (cached) {
    try {
      const s = JSON.parse(cached);
      document.getElementById('statActiveRides').innerText = s.activeRides || s.active_rides || '0';
      document.getElementById('statTotalStudents').innerText = s.totalStudents || s.total_students || '0';
      document.getElementById('statMatchedRides').innerText = s.matchedRides || s.matched_rides || '0';
    } catch(e) {}
  }

  // 2. Background fresh fetch
  try {
    const res = await API.getCampusStats();
    if (res.success && res.stats) {
      document.getElementById('statActiveRides').innerText = res.stats.activeRides || '0';
      document.getElementById('statTotalStudents').innerText = res.stats.totalStudents || '0';
      document.getElementById('statMatchedRides').innerText = res.stats.matchedRides || '0';
      localStorage.setItem('glim_cached_stats', JSON.stringify(res.stats));
    } else if (res.active_rides !== undefined) {
      document.getElementById('statActiveRides').innerText = res.active_rides || '0';
      document.getElementById('statTotalStudents').innerText = res.total_students || '0';
      document.getElementById('statMatchedRides').innerText = res.matched_rides || '0';
      localStorage.setItem('glim_cached_stats', JSON.stringify(res));
    }
  } catch (e) {
    console.warn('Stats background sync note:', e.message);
  }
}

// 10. Event Listeners & Utilities
function initEventListeners() {
  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Search Form
  document.getElementById('searchRidesForm').addEventListener('submit', handleSearchRides);

  // Post Form
  document.getElementById('postRideForm').addEventListener('submit', handleCreateRide);

  // Edit Ride Form
  const editForm = document.getElementById('editRideForm');
  if (editForm) editForm.addEventListener('submit', handleEditRideSubmit);
  const closeEditBtn = document.getElementById('closeEditModalBtn');
  if (closeEditBtn) closeEditBtn.addEventListener('click', closeEditRideModal);

  // Pool Filters
  document.getElementById('poolDestFilter').addEventListener('change', loadPublicPool);
  document.getElementById('poolDateFilter').addEventListener('change', loadPublicPool);
  document.getElementById('poolTypeFilter').addEventListener('change', loadPublicPool);
  document.getElementById('clearPoolFilterBtn').addEventListener('click', () => {
    document.getElementById('poolDestFilter').value = 'ALL';
    document.getElementById('poolDateFilter').value = '';
    document.getElementById('poolTypeFilter').value = 'ALL';
    loadPublicPool();
  });

  // Direct Login Form
  const loginForm = document.getElementById('directLoginForm');
  if (loginForm) loginForm.addEventListener('submit', handleDirectLogin);
  const closeLoginBtn = document.getElementById('closeModalBtn');
  if (closeLoginBtn) closeLoginBtn.addEventListener('click', closeLoginModal);

  // Global click-outside & Escape key to close any modal
  window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-backdrop') || e.target.classList.contains('modal-overlay')) {
      closeLoginModal();
      closeEditRideModal();
      closeSheetsSyncModal();
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeLoginModal();
      closeEditRideModal();
      closeSheetsSyncModal();
    }
  });
}

function copyContact(phone, name) {
  navigator.clipboard.writeText(phone);
  showToast(`Copied ${name}'s phone number (${phone}) to clipboard! 📋`, 'info');
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>🔔</span> <span>${escapeHTML(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// -------------------------------------------------------------
// Google Sheets Cloud Sync Management
// -------------------------------------------------------------

function checkSyncStatus() {
  const url = API.getSheetsUrl();
  const dot = document.getElementById('syncStatusDot');
  const text = document.getElementById('syncStatusText');
  const badge = document.getElementById('syncCurrentStatusBadge');
  const input = document.getElementById('sheetsUrlInput');

  if (input) input.value = url;

  if (url) {
    if (dot) dot.textContent = '🟢';
    if (text) text.textContent = 'Sheets Sync';
    if (badge) {
      badge.style.background = '#DCFCE7';
      badge.style.color = '#15803D';
      badge.textContent = '🟢 Google Sheet Connected';
    }
  } else {
    // Check if running on localhost backend or static
    const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    if (dot) dot.textContent = isLocal ? '🔵' : '📊';
    if (text) text.textContent = isLocal ? 'Local Server' : 'Cloud Sync';
    if (badge) {
      if (isLocal) {
        badge.style.background = '#EFF6FF';
        badge.style.color = '#1D4ED8';
        badge.textContent = '🔵 Local Node Server (rides.db)';
      } else {
        badge.style.background = '#FEF3C7';
        badge.style.color = '#B45309';
        badge.textContent = '🟡 Browser Fallback (Connect Sheet to Sync Devices)';
      }
    }
  }
}

function openSheetsSyncModal() {
  if (!State.currentStudent || State.currentStudent.roll_number?.toUpperCase() !== 'FT271049') {
    alert('⚠️ Google Sheets Cloud Sync management is restricted to Admin FT271049 (Ankit Agrawal).');
    return;
  }
  checkSyncStatus();
  document.getElementById('sheetsSyncModal').classList.add('active');
}

function closeSheetsSyncModal() {
  document.getElementById('sheetsSyncModal').classList.remove('active');
}

async function saveSheetsSync() {
  if (!State.currentStudent || State.currentStudent.roll_number?.toUpperCase() !== 'FT271049') {
    alert('Only Admin FT271049 can update Google Sheets sync settings.');
    return;
  }
  const input = document.getElementById('sheetsUrlInput');
  const btn = document.getElementById('saveSheetsUrlBtn');
  const url = input.value.trim();

  if (!url) {
    API.setSheetsUrl('');
    checkSyncStatus();
    showToast('Cloud Sync disabled. Using default mode.', 'info');
    closeSheetsSyncModal();
    return;
  }

  if (!url.startsWith('https://script.google.com/')) {
    alert('Please enter a valid Google Apps Script URL starting with https://script.google.com/');
    return;
  }

  btn.disabled = true;
  btn.textContent = '⏳ Testing Connection...';

  try {
    const testRes = await fetch(`${url}?action=stats`);
    const data = await testRes.json();
    
    API.setSheetsUrl(url);
    checkSyncStatus();
    btn.disabled = false;
    btn.textContent = '💾 Connect & Save';
    closeSheetsSyncModal();
    showToast('🎉 Connected to Google Sheet! Data now synchronizes across all devices in real time.', 'success');
    
    // Refresh stats & views
    loadCampusStats();
    if (State.activeTab === 'pool') loadPublicPool();
    if (State.activeTab === 'dashboard') loadStudentDashboard();
  } catch (err) {
    btn.disabled = false;
    btn.textContent = '💾 Connect & Save';
    alert('Could not connect to Google Sheet. Make sure you selected "Anyone" in "Who has access" when deploying the Apps Script.\n\nError: ' + err.message);
  }
}

function clearSheetsSync() {
  if (!State.currentStudent || State.currentStudent.roll_number?.toUpperCase() !== 'FT271049') {
    alert('Only Admin FT271049 can disconnect or change the Google Sheet.');
    return;
  }
  API.setSheetsUrl('');
  const input = document.getElementById('sheetsUrlInput');
  if (input) input.value = '';
  checkSyncStatus();
  showToast('Google Sheet disconnected.', 'info');
  closeSheetsSyncModal();
  loadCampusStats();
}

async function handleTriggerArchive() {
  if (!State.currentStudent || State.currentStudent.roll_number?.toUpperCase() !== 'FT271049') {
    alert('Only Admin FT271049 can run database archiving.');
    return;
  }

  const btn = document.getElementById('archivePastRidesBtn');
  const originalText = btn ? btn.innerHTML : '🧹 Archive Past Rides';
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '⏳ Archiving...';
  }

  try {
    const res = await API.archivePastRides(3);
    showToast(res.message || 'Database cleaned and archived successfully!', 'success');
    loadCampusStats();
    if (State.activeTab === 'pool') loadPublicPool();
    if (State.activeTab === 'dashboard') loadMyRides();
  } catch (err) {
    showToast(err.message || 'Archiving failed. Please verify your Google Apps Script deployment.', 'danger');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
  }
}


