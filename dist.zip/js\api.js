// API Client with Live Server, Google Sheets Cloud Sync + Standalone Fallback
const API = {
  baseURL: window.CAB_API_URL || '/api',
  
  // Google Sheets Cloud Sync URL
  getSheetsUrl() {
    return window.CAB_CONFIG?.GOOGLE_SHEETS_URL || window.CAB_SHEETS_URL || localStorage.getItem('glim_sheets_url') || '';
  },

  setSheetsUrl(url) {
    if (url && url.trim()) {
      localStorage.setItem('glim_sheets_url', url.trim());
    } else {
      localStorage.removeItem('glim_sheets_url');
    }
  },

  isCloudSyncActive() {
    return Boolean(this.getSheetsUrl());
  },

  // Main request dispatcher
  async request(endpoint, options = {}) {
    const sheetsUrl = this.getSheetsUrl();

    // If Google Sheets Cloud Sync is configured, route all requests directly to Google Apps Script
    if (sheetsUrl) {
      try {
        return await this._gasRouter(endpoint, options, sheetsUrl);
      } catch (gasErr) {
        console.warn('Google Sheets API request failed, checking fallback:', gasErr);
        // If Google Apps Script network fails, fall back to offline storage
        return this._fallbackHandler(endpoint, options);
      }
    }

    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const res = await fetch(url, config);
      
      // If deployed as static-only (e.g. Netlify Drop) where /api gives 404 HTML, switch to offline fallback
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok && (!contentType.includes('application/json') || res.status === 404)) {
        console.warn(`API endpoint ${endpoint} not found on server. Using client-side storage mode.`);
        return this._fallbackHandler(endpoint, options);
      }

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'API Request failed');
      }
      return data;
    } catch (err) {
      console.warn(`Network error on ${endpoint}. Engaging fallback handler:`, err.message);
      return this._fallbackHandler(endpoint, options);
    }
  },

  // Route requests to Google Apps Script Web App
  async _gasRouter(endpoint, options = {}, gasUrl) {
    const urlParts = endpoint.split('?');
    const path = urlParts[0];
    const queryParams = new URLSearchParams(urlParts[1] || '');
    const method = (options.method || 'GET').toUpperCase();
    const body = options.body ? JSON.parse(options.body) : {};

    // 1. Send OTP
    if (path === '/auth/send-otp') {
      return this._gasFetch(gasUrl, 'POST', { action: 'sendOtp', ...body });
    }

    // 2. Verify OTP
    if (path === '/auth/verify-otp') {
      return this._gasFetch(gasUrl, 'POST', { action: 'verifyOtp', ...body });
    }

    // 3. Login
    if (path === '/auth/login') {
      return this._gasFetch(gasUrl, 'POST', { action: 'login', ...body });
    }

    // 4. Get Student
    if (path.startsWith('/auth/student/')) {
      const roll = decodeURIComponent(path.split('/')[3]);
      return this._gasFetch(gasUrl, 'GET', { action: 'getStudent', roll_number: roll });
    }

    // 5. Search Rides
    if (path === '/rides/search') {
      const p = Object.fromEntries(queryParams.entries());
      const res = await this._gasFetch(gasUrl, 'GET', { action: 'search', ...p });
      
      // Format to match app.js expectation
      return {
        success: true,
        exact_matches_count: res.totalExact || 0,
        exact_matches: (res.exactMatches || []).map(r => this._normalizeRide(r, p.travel_date, p.travel_time)),
        same_day_matches_count: res.totalOther || 0,
        same_day_matches: (res.otherOptions || []).map(r => this._normalizeRide(r, p.travel_date, p.travel_time))
      };
    }

    // 6. Public Pool
    if (path === '/rides/pool') {
      const p = Object.fromEntries(queryParams.entries());
      const res = await this._gasFetch(gasUrl, 'GET', { action: 'pool', ...p });
      return {
        success: true,
        count: res.count || 0,
        posts: (res.rides || []).map(r => this._normalizeRide(r))
      };
    }

    // 7. Create Ride
    if (path === '/rides' && method === 'POST') {
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'createRide', ...body });
      return { success: true, message: res.message || 'Ride posted!', ride: res.ride };
    }

    // 8. Get Single Ride
    if (path.startsWith('/rides/') && method === 'GET' && !path.includes('/student/') && !path.includes('/seats') && !path.includes('/status')) {
      const rideId = path.split('/')[2];
      const res = await this._gasFetch(gasUrl, 'GET', { action: 'getRide', id: rideId });
      const rawRide = res.ride || res;
      return { success: true, ride: rawRide ? this._normalizeRide(rawRide) : null };
    }

    // 9. Update Seats
    if (path.includes('/seats')) {
      const rideId = path.split('/')[2];
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'updateSeats', ride_id: rideId, ...body });
      return { success: true, message: 'Seats updated!', ...res };
    }

    // 10. Update Ride details
    if (path.startsWith('/rides/') && method === 'PUT') {
      const rideId = path.split('/')[2];
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'updateRide', id: rideId, ...body });
      return { success: true, message: res.message || 'Ride updated!' };
    }

    // 11. Update Status
    if (path.includes('/status')) {
      const rideId = path.split('/')[2];
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'updateStatus', id: rideId, ...body });
      return { success: true, message: res.message || 'Status updated!' };
    }

    // 12. Delete Ride
    if (path.startsWith('/rides/') && method === 'DELETE') {
      const rideId = path.split('/')[2];
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'deleteRide', id: rideId, ...body });
      return { success: true, message: res.message || 'Ride deleted!' };
    }

    // 13. My Rides
    if (path.startsWith('/rides/student/')) {
      const studentId = path.split('/')[3];
      const res = await this._gasFetch(gasUrl, 'GET', { action: 'myRides', student_id: studentId });
      return {
        success: true,
        rides: [...(res.activeRides || []), ...(res.pastRides || [])].map(r => this._normalizeRide(r)),
        active_rides: (res.activeRides || []).map(r => this._normalizeRide(r)),
        past_rides: (res.pastRides || []).map(r => this._normalizeRide(r))
      };
    }

    // 14. Stats
    if (path === '/stats') {
      const stats = await this._gasFetch(gasUrl, 'GET', { action: 'stats' });
      return {
        success: true,
        stats: {
          totalStudents: stats.total_students || 0,
          activeRides: stats.active_rides || 0,
          matchedRides: stats.matched_rides || 0,
          popularDestinations: []
        }
      };
    }

    // 15. Archive Past Rides (Admin)
    if (path === '/admin/archive-past-rides') {
      const days = body.days || 3;
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'archivePastRides', days });
      return { success: true, ...res };
    }

    // 16. Setup Archive Trigger (Admin)
    if (path === '/admin/setup-archive-trigger') {
      const res = await this._gasFetch(gasUrl, 'POST', { action: 'setupArchiveTrigger' });
      return { success: true, ...res };
    }

    return { success: true };
  },

  async _gasFetch(gasUrl, method, payload) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); // 8s safety timeout

    try {
      if (method === 'GET') {
        const query = new URLSearchParams(payload).toString();
        const res = await fetch(`${gasUrl}?${query}`, { 
          method: 'GET',
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        const data = await res.json();
        if (data && data.error) {
          throw new Error(data.error);
        }
        
        // Cache stats and pool responses for instant rendering
        if (payload.action === 'stats') {
          this._setStorage('cached_stats', data);
        } else if (payload.action === 'pool') {
          this._setStorage('cached_pool', data);
        }
        
        return data;
      } else {
        // POST: Use text/plain header to avoid CORS preflight options blocking on Google Apps Script
        const res = await fetch(gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        const data = await res.json();
        if (data && data.error) {
          throw new Error(data.error);
        }
        return data;
      }
    } catch (err) {
      clearTimeout(timeoutId);
      console.warn('Google Sheets network request failed or timed out:', err.message);
      
      // Serve cached version if available for GET
      if (method === 'GET' && payload.action === 'stats') {
        const cached = this._getStorage('cached_stats', null);
        if (cached) return cached;
      }
      if (method === 'GET' && payload.action === 'pool') {
        const cached = this._getStorage('cached_pool', null);
        if (cached) return cached;
      }
      
      throw err;
    }
  },

  _normalizeRide(r, targetDate, targetTime) {
    const total = Number(r.total_seats) || 3;
    const filled = Number(r.filled_seats) || 0;
    let diffMinutes = 0;
    let diffLabel = '';

    let dateStr = String(r.travel_date || '').trim();
    if (dateStr.includes('T')) dateStr = dateStr.split('T')[0];
    if (dateStr.includes('GMT') || (dateStr.includes(' ') && !dateStr.match(/^\d{4}-\d{2}-\d{2}$/))) {
      try {
        const d = new Date(dateStr);
        if (!isNaN(d.getTime())) {
          const y = d.getFullYear();
          const m = String(d.getMonth() + 1).padStart(2, '0');
          const day = String(d.getDate()).padStart(2, '0');
          dateStr = `${y}-${m}-${day}`;
        }
      } catch (e) {}
    }

    let timeStr = String(r.travel_time || '').trim();
    const timeMatch = timeStr.match(/(\d{1,2}):(\d{2})/);
    if (timeMatch) {
      timeStr = `${timeMatch[1].padStart(2, '0')}:${timeMatch[2]}`;
    }

    const rollStr = String(r.roll_number || '').toUpperCase();
    const phoneStr = String(r.phone_number || r.whatsapp_number || '');
    const nameStr = String(r.full_name || r.student_name || 'GLIM Student');
    const statusStr = String(r.status || 'ACTIVE').toUpperCase();

    if (targetDate && targetTime && r.travel_timestamp) {
      const [th, tm] = String(targetTime).split(':').map(Number);
      const [ty, tmo, td] = String(targetDate).split('-').map(Number);
      const targetTs = Math.floor(new Date(ty, tmo - 1, td, th, tm, 0).getTime() / 1000);
      diffMinutes = Math.round((Number(r.travel_timestamp) - targetTs) / 60);
      diffLabel = diffMinutes === 0 ? 'Exact same time' : `${Math.abs(diffMinutes)} mins ${diffMinutes > 0 ? 'after' : 'before'} your time`;
    }

    return {
      ...r,
      student_name: nameStr,
      roll_number: rollStr,
      phone_number: phoneStr,
      whatsapp_number: phoneStr,
      origin: String(r.origin || 'GLIM Campus (Manamai)'),
      destination: String(r.destination || ''),
      travel_date: dateStr,
      travel_time: timeStr,
      status: statusStr,
      notes: String(r.notes || ''),
      cohort: rollStr.startsWith('FT') ? 'FT Batch' : (rollStr.startsWith('DM') ? 'DM Batch' : 'GLIM'),
      total_seats: total,
      filled_seats: filled,
      remaining_seats: Math.max(0, total - filled),
      is_full: total <= filled,
      diff_minutes: diffMinutes,
      diff_label: diffLabel
    };
  },

  // Auth & WhatsApp OTP
  sendOtp(phoneNumber, rollNumber) {
    return this.request('/auth/send-otp', {
      method: 'POST',
      body: JSON.stringify({ phone_number: phoneNumber, roll_number: rollNumber })
    });
  },

  verifyOtp(phoneNumber, otpCode, rollNumber, fullName) {
    return this.request('/auth/verify-otp', {
      method: 'POST',
      body: JSON.stringify({
        phone_number: phoneNumber,
        otp_code: otpCode,
        roll_number: rollNumber,
        full_name: fullName
      })
    });
  },

  login(studentData) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(studentData)
    });
  },

  getStudent(rollNumber) {
    return this.request(`/auth/student/${encodeURIComponent(rollNumber)}`);
  },

  // Rides & Seats
  searchRides(params) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/rides/search?${query}`);
  },

  getPublicPool(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/rides/pool?${query}`);
  },

  createRide(rideData) {
    return this.request('/rides', {
      method: 'POST',
      body: JSON.stringify(rideData)
    });
  },

  getRide(rideId) {
    return this.request(`/rides/${encodeURIComponent(rideId)}`);
  },

  updateRide(rideId, rideData) {
    return this.request(`/rides/${encodeURIComponent(rideId)}`, {
      method: 'PUT',
      body: JSON.stringify(rideData)
    });
  },

  updateSeats(rideId, payload) {
    return this.request(`/rides/${encodeURIComponent(rideId)}/seats`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });
  },

  getMyRides(studentId) {
    return this.request(`/rides/student/${encodeURIComponent(studentId)}`);
  },

  updateRideStatus(rideId, status, studentId) {
    return this.request(`/rides/${encodeURIComponent(rideId)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, student_id: studentId })
    });
  },

  deleteRide(rideId, studentId) {
    return this.request(`/rides/${encodeURIComponent(rideId)}`, {
      method: 'DELETE',
      body: JSON.stringify({ student_id: studentId })
    });
  },

  getCampusStats() {
    return this.request('/stats');
  },

  archivePastRides(days = 3) {
    return this.request('/admin/archive-past-rides', {
      method: 'POST',
      body: JSON.stringify({ days })
    });
  },

  setupArchiveTrigger() {
    return this.request('/admin/setup-archive-trigger', {
      method: 'POST'
    });
  },

  // --- Client-side fallback handler for pure static Netlify hosting ---
  _getStorage(key, defaultVal = []) {
    try {
      const data = localStorage.getItem(`glim_static_${key}`);
      return data ? JSON.parse(data) : defaultVal;
    } catch (e) {
      return defaultVal;
    }
  },

  _setStorage(key, val) {
    try {
      localStorage.setItem(`glim_static_${key}`, JSON.stringify(val));
    } catch (e) {}
  },

  _fallbackHandler(endpoint, options = {}) {
    const urlParts = endpoint.split('?');
    const path = urlParts[0];
    const queryParams = new URLSearchParams(urlParts[1] || '');
    const method = (options.method || 'GET').toUpperCase();
    const body = options.body ? JSON.parse(options.body) : {};

    const currentUnix = Math.floor(Date.now() / 1000);

    // 1. Send OTP
    if (path === '/auth/send-otp') {
      const devOtp = '123456';
      return {
        success: true,
        message: `WhatsApp OTP sent to +91 ${String(body.phone_number).slice(-10)}`,
        dev_otp: devOtp
      };
    }

    // 2. Verify OTP / Login
    if (path === '/auth/verify-otp' || path === '/auth/login') {
      const students = this._getStorage('students', []);
      let roll = (body.roll_number || 'FT24001').toUpperCase();
      let student = students.find(s => s.roll_number === roll);
      
      if (!student) {
        student = {
          id: 'stud_' + Date.now(),
          roll_number: roll,
          full_name: body.full_name || 'GLIM Student',
          phone_number: body.phone_number || '9876543210',
          whatsapp_number: body.phone_number || '9876543210',
          cohort: roll.startsWith('FT') ? 'FT Batch' : (roll.startsWith('DM') ? 'DM Batch' : 'GLIM'),
          is_admin: roll === 'FT271049',
          role: roll === 'FT271049' ? 'ADMIN' : 'STUDENT'
        };
        students.push(student);
        this._setStorage('students', students);
      }
      return { success: true, student };
    }

    // 3. Search Rides
    if (path === '/rides/search') {
      const origin = queryParams.get('origin') || 'GLIM Campus (Manamai)';
      const destination = queryParams.get('destination');
      const travelDate = queryParams.get('travel_date');
      const travelTime = queryParams.get('travel_time');
      const currentStudentId = queryParams.get('current_student_id');

      const allRides = this._getStorage('rides', []);
      const [sh, sm] = (travelTime || '12:00').split(':').map(Number);
      const [sy, smo, sd] = (travelDate || '2026-10-15').split('-').map(Number);
      const searchTimestamp = Math.floor(new Date(sy, smo - 1, sd, sh, sm, 0).getTime() / 1000);

      const activeUpcoming = allRides.filter(r => 
        r.status === 'ACTIVE' && 
        r.destination === destination && 
        r.travel_date === travelDate && 
        r.student_id !== currentStudentId &&
        r.travel_timestamp >= (currentUnix - 1800)
      );

      const exact = [];
      const sameDay = [];

      activeUpcoming.forEach(r => {
        const diffMinutes = Math.round((r.travel_timestamp - searchTimestamp) / 60);
        const total = r.total_seats || r.seats_count || 1;
        const filled = r.filled_seats || 0;
        const item = {
          ...r,
          diff_minutes: diffMinutes,
          diff_label: diffMinutes === 0 ? 'Exact same time' : `${Math.abs(diffMinutes)} mins ${diffMinutes > 0 ? 'after' : 'before'} your time`,
          total_seats: total,
          filled_seats: filled,
          remaining_seats: Math.max(0, total - filled),
          is_full: total <= filled
        };

        if (Math.abs(diffMinutes) <= 60) {
          exact.push({ ...item, is_exact_window: true });
        } else {
          sameDay.push({ ...item, is_exact_window: false });
        }
      });

      return {
        success: true,
        exact_matches_count: exact.length,
        exact_matches: exact,
        same_day_matches_count: sameDay.length,
        same_day_matches: sameDay
      };
    }

    // 4. Public Pool
    if (path === '/rides/pool') {
      const allRides = this._getStorage('rides', []);
      const dest = queryParams.get('destination');
      const date = queryParams.get('date');

      let filtered = allRides.filter(r => r.status === 'ACTIVE' && r.travel_timestamp >= (currentUnix - 1800));
      if (dest && dest !== 'ALL') filtered = filtered.filter(r => r.destination === dest);
      if (date) filtered = filtered.filter(r => r.travel_date === date);

      return {
        success: true,
        count: filtered.length,
        posts: filtered.map(r => {
          const total = r.total_seats || r.seats_count || 1;
          const filled = r.filled_seats || 0;
          return {
            ...r,
            total_seats: total,
            filled_seats: filled,
            remaining_seats: Math.max(0, total - filled),
            is_full: total <= filled
          };
        })
      };
    }

    // 5. Create Ride
    if (path === '/rides' && method === 'POST') {
      const allRides = this._getStorage('rides', []);
      const [h, m] = (body.travel_time || '12:00').split(':').map(Number);
      const [y, mo, d] = (body.travel_date || '2026-10-15').split('-').map(Number);
      const timestamp = Math.floor(new Date(y, mo - 1, d, h, m, 0).getTime() / 1000);

      const total = Number(body.total_seats || body.seats_count) || 3;
      const filled = Number(body.filled_seats) || 1;
      const newRide = {
        id: 'ride_' + Date.now(),
        student_id: body.student_id || 'stud_demo',
        student_name: body.student_profile?.full_name || 'GLIM Student',
        roll_number: body.student_profile?.roll_number || 'FT24102',
        phone_number: body.student_profile?.phone_number || '9876543210',
        whatsapp_number: body.student_profile?.phone_number || '9876543210',
        cohort: body.student_profile?.cohort || 'GLIM',
        origin: body.origin || 'GLIM Campus (Manamai)',
        destination: body.destination,
        travel_date: body.travel_date,
        travel_time: body.travel_time,
        travel_timestamp: timestamp,
        ride_type: body.ride_type || 'LOOKING_FOR_CAB',
        seats_count: total,
        total_seats: total,
        filled_seats: filled,
        luggage_size: body.luggage_size || 'Medium',
        flight_train_no: body.flight_train_no || '',
        notes: body.notes || '',
        status: 'ACTIVE',
        created_at: new Date().toISOString()
      };

      allRides.unshift(newRide);
      this._setStorage('rides', allRides);
      return { success: true, message: 'Ride posted!', ride: newRide };
    }

    // 6. Get My Rides
    if (path.startsWith('/rides/student/')) {
      const studentId = path.split('/')[3];
      const allRides = this._getStorage('rides', []);
      const myRides = allRides.filter(r => r.student_id === studentId);
      
      const active = myRides.filter(r => r.status === 'ACTIVE' && r.travel_timestamp >= (currentUnix - 1800));
      const past = myRides.filter(r => r.status !== 'ACTIVE' || r.travel_timestamp < (currentUnix - 1800));

      return {
        success: true,
        rides: myRides,
        active_rides: active,
        past_rides: past
      };
    }

    // 7. Update Seats
    if (path.includes('/seats')) {
      const rideId = path.split('/')[2];
      const allRides = this._getStorage('rides', []);
      const ride = allRides.find(r => r.id === rideId);
      if (ride) {
        const total = ride.total_seats || 3;
        if (body.delta !== undefined) {
          ride.filled_seats = Math.max(1, Math.min(total, (ride.filled_seats || 1) + body.delta));
        }
        this._setStorage('rides', allRides);
        return { success: true, message: 'Seats updated!', ride };
      }
    }

    // 8. Update Status / Delete
    if (path.includes('/status')) {
      const rideId = path.split('/')[2];
      const allRides = this._getStorage('rides', []);
      const ride = allRides.find(r => r.id === rideId);
      if (ride) {
        ride.status = body.status;
        this._setStorage('rides', allRides);
        return { success: true, message: 'Status updated!', ride };
      }
    }

    if (method === 'DELETE') {
      const rideId = path.split('/')[2];
      let allRides = this._getStorage('rides', []);
      allRides = allRides.filter(r => r.id !== rideId);
      this._setStorage('rides', allRides);
      return { success: true, message: 'Ride deleted successfully' };
    }

    // Stats
    if (path === '/stats') {
      const allRides = this._getStorage('rides', []);
      const active = allRides.filter(r => r.status === 'ACTIVE').length;
      return {
        success: true,
        stats: {
          totalStudents: 1,
          activeRides: active,
          matchedRides: 0,
          popularDestinations: []
        }
      };
    }

    return { success: true };
  }
};
