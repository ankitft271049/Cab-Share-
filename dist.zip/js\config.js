// Global Configuration for GLIM Cab Share
window.CAB_CONFIG = {
  // Google Spreadsheet Link
  SHEET_DOCUMENT_URL: 'https://docs.google.com/spreadsheets/d/1WQt4lh38aL9dmydk-wnLuAox6LMD6YxQKc80qeEZ0cw/edit',
  
  // Google Apps Script Web App Deployment URL
  GOOGLE_SHEETS_URL: 'https://script.google.com/macros/s/AKfycbzTpM4wHn5S0ywToS0pTLbmTRyQQdrW9Qs25qZpSyfvtGZfGXIT4tPVzOYoS2LakzCVkA/exec'
};
